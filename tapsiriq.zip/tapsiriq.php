<?php
include"headertapsiriq.php";

echo '<div class="container">';


$yaranma=date('Y-m-d H:i:s');
//---------------------------------------------------FORM-------------------------------------------------//

if(!isset($_POST['edit']))
{
	echo'
	<div class="alert alert-primary" role="alert"> 
  <form method="post">
	Tapsiriq:<br>
	<input type="text" name="tapsiriq" class="form-control">
	Son vaxt:<br>
	<input type="date" name="sonvaxt" class="form-control">
	Saat:<br>
	<input type="time" name="saat" class="form-control"><br>
	<button type="submit" name="insert" class="btn btn-dark">Gir</button>

    </form>
    </div>';	
}

if(isset($_POST['edit']))
{
	$edit=mysqli_query($con,"SELECT * FROM mytapsiriq WHERE id='".$_POST['id']."' ");
	$info=mysqli_fetch_array($edit);

	echo'
	<div class="alert alert-primary" role="alert">
  <form method="post">
	Tapsiriq:<br>
	<input type="text" name="tapsiriq" value="'.$info['tapsiriq'].'" class="form-control">
	Son vaxt:<br>
	<input type="date" name="sonvaxt" value="'.$info['sonvaxt'].'" class="form-control">
	Saat:<br>
	<input type="time" name="saat" value="'.$info['saat'].'" class="form-control"><br>
	<button type="submit" name="update" class="btn btn-primary">Yenile</button>
	</form>
  </div>';	
}


//----------------------------------------------------UPDATE---------------------------------//


if(isset($_POST['update']))
{
    $tapsiriq=mysqli_real_escape_string($con,htmlspecialchars(strip_tags(trim($_POST['tapsiriq']))));


 if(!empty($tapsiriq) && !empty($_POST['sonvaxt']) && !empty($_POST['saat']))
  
  {
    $yenile=mysqli_query($con,"UPDATE mytapsiriq SET
    										tapsiriq='".$tapsiriq."',
    										sonvaxt='".$_POST['sonvaxt']."',
    										saat='".$_POST['saat']."'

    										WHERE id='".$_POST['id']."' ");

    if($yenile==true)
    {echo'<div class="alert alert-success" role="alert">Melumat ugurla yenilendi!</div>';}
    else
    {echo'<div class="alert alert-danger" role="alert">Melumati yenilemek mumkun olmadi!<br>';}

 }

else
{echo'<div class="alert alert-warning" role="alert">Lutfen melumatlari tam doldurun!<br>';}

}









//------------------------------------------DELETE----------------------------------------//

if(isset($_POST['delete']))
{
	echo' Silmeye eminsiniz ?

	<form method="post">

	<button type="submit" name="he" class="btn btn-success">He</button>
	<button type="submit" name="yox" class="btn btn-danger">Yox</button>
	<input type="hidden" name="id" value="'.$_POST['id'].'">

	</form>
	';
}

if(isset($_POST['he']))
{
	$sil=mysqli_query($con,"DELETE FROM mytapsiriq WHERE id='".$_POST['id']."'");

	if($sil==true)
	{echo'<div class="alert alert-success" role="alert">Melumatlar ugurla silindi !</div>';}
    else
    {echo'<div class="alert alert-danger" role="alert">Melumatlar silinmedi !</div>';}
}

//-------------------------------------------------DAXIL------------------------------------------------//

if(isset($_POST['insert']))
{
	$tapsiriq=mysqli_real_escape_string($con,htmlspecialchars(strip_tags(trim($_POST['tapsiriq']))));


	if(!empty($tapsiriq))
    {
    	if($yaranma<$_POST['sonvaxt'] or $_POST['saat'])
    	{
				$daxil=mysqli_query($con,"INSERT INTO mytapsiriq(tapsiriq,sonvaxt,saat,yaranma) 
				VALUES('".$tapsiriq."','".$_POST['sonvaxt']."','".$_POST['saat']."','".$yaranma."')");

				if($daxil==true)
				{echo'<div class="alert alert-success" role="alert">Melumatlarin cavabi hazirdir.</div>';}
				else
				{echo'<div class="alert alert-danger" role="alert">Melumatlar hesablana bilmedi.</div>';}

		}
			else
			{echo'<div class="alert alert-danger" role="alert">Gelecek vaxt indikinden az ola bilmez!</div>';}
	}
else
	{echo'<div class="alert alert-warning">Bos xanalari doldurun !</div>';}
}

	


//-------------------------------------------SELECT-----------------------------------------//

if(isset($_POST['axtar']) && !empty($_POST['sorgu']))
{
  $axtar = " WHERE (tapsiriq LIKE '%".$_POST['sorgu']."%') ";
}

$sec=mysqli_query($con,"SELECT * FROM mytapsiriq ".$axtar." ORDER BY id DESC");
$say=mysqli_num_rows($sec);




echo'
<div class="alert alert-secondary" role="alert">
<b>Toplam tapsiriq: '.$say.'</b>
<b>Aktiv tapsiriq:'.$aktiv.'</b>
<b>Bitmis tapsiriq:'.$bitmish.'</b>
</div>';



echo'
    <table class="table">
    <thead class="thead-dark">

        <th>#</th>
        <th>Tapsiriq</th>
        <th>Vaxt</th>
        <th>Saat</th>
        <th>Yaradildi</th>
        <th>Qalan Vaxt</th>
        <th></th>

        </thead>

        <tbody>';





$aktiv=0;
$bitmish=0;



$i=0;
while($info=mysqli_fetch_array($sec)) 
{
	$t=time();
	$t1=strtotime($info['sonvaxt'].' '.$info['saat']);
	$t2=strtotime(date('Y-m-d H:i:s'));


$san=$t1-$t2;
$deq=round($san/60);
$saat=round($deq/60);
$gun=round($saat/24);

if($deq>0 && $deq<60 && $saat<1)
	{$qalanvaxt = $deq.'deq';}

if($deq>59 && $saat<25)
	{$qalanvaxt = $saat.'saat';}

if($saat>24)
	{$qalanvaxt = $gun.'gun';}



	$i++;


if($qalanvaxt==0)
	{$class='class="alert alert-success" ';}
else
	{$class='class="alert alert-warning" ';}

if($qalanvaxt==0)
{$qalanvaxt='<button class="btn btn-success"><i class="bi bi-check"></i></button>';}

  	echo'<tr '.$class.'>';
	echo'<td>'.$i.'</td>';
	echo'<td>'.$info['tapsiriq'].'</td>';
	echo'<td>'.$info['sonvaxt'].'</td>';
	echo'<td>'.$info['saat'].'</td>';
	echo'<td>'.$info['yaranma'].'</td>';
	echo'<td>'.$qalanvaxt.'</td>';


echo'<td>
<form method="post">
<input type="hidden" name="id" value="'.$info['id'].'">
<button type="submit" class="btn btn-success" name="edit" title="Edit"><i class="bi bi-pen"></i></button>

<button type="submit" name="delete" class="btn btn-danger" title="SIL"><i class="bi bi-trash"></i></button>
</form>
</td>';

echo'</tr>';

}

echo'</tbody>
</table>

</div>';
?>
